<?php
// Heading
$_['heading_title']    = 'Giga E-commerce API';

// Text
$_['text_extension']   = 'Extensões';
$_['text_success']     = 'Giga E-commerce API modificado com sucesso.';
$_['text_edit']        = 'Editando Giga E-commerce API';

// Entry
$_['entry_status']     = 'Situação';

// Errorentry_head
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar a extensão Giga E-commerce API!';

$_['text_success_sync'] = 'Sincronização concluída';
$_['text_auth_error'] = 'Erro de autenticação';